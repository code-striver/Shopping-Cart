import { createContext } from "react";
import { useState } from 'react';
import data from "./data/itemData";
import CartModal from "./components/CartModal";
const itemContext = createContext();

function ContextItem(props){
    const [total, setTotal] = useState(0);
    const [item, setItem] = useState(0);
    const [showCart, setShowCart] = useState(false)
    const [cart, setCart] = useState([]);
    function toggle(e){
        e.preventDefault();
        setShowCart(!showCart)
    }
    function clear(e){
        e.preventDefault();
        setTotal(0);
        setItem(0);
        setCart([]);
        
    }
    return(
        <itemContext.Provider value={{cart, setCart,
        total, setTotal, item, setItem, data, toggle, clear}}>
            {showCart&&<CartModal/>}
            {props.children}
        </itemContext.Provider>
    )
}
export {itemContext}
export default ContextItem