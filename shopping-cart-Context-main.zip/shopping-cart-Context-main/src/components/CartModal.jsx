import React, { useContext } from "react";
import styles from "../styles/CartModal.module.css";
import { itemContext } from "../intemcontext";
import { isEditable } from "@testing-library/user-event/dist/utils";
function CartModal() {
  const {cart, setCart,
    total, setTotal, item, setItem, data, toggle, clear} = useContext(itemContext);
  return (
    <div className={styles.cartModal}>
      <div className={styles.closeButton} onClick={toggle}>
        Close
      </div>
      <div className={styles.clearButton} onClick={clear}>
        Clear
      </div>
      <div className={styles.itemContainer}>
        {cart.map((item)=>{
          return (
            <div className={styles.cartCard} key={item.id}>
              <h1>{item.name}</h1>
              <h3>X {item.qty}</h3>
              <h3>X {item.qty*item.price}</h3>
            </div>
          )
        })}
      </div>
      <div className={styles.total}>
        <div className={styles.totalText}>Total</div>
        <div className={styles.totalPrice}>${cart.reduce((agg, currval)=>{
          agg = agg+(currval.qty*currval.price)
          return agg
        }, 0)}</div>
      </div>
    </div>
  );
}

export default CartModal;
