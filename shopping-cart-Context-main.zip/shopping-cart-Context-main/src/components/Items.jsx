import styles from "../styles/Item.module.css";
import ItemCard from "./ItemCard";
import { itemContext } from "../intemcontext";
import { useContext } from "react";

function Items() {
  const value = useContext(itemContext);
  return (
    <div className={styles.wrapper}>
     {value.data.map((item)=><ItemCard prod = {item} />)} 
    </div>
  );
}

export default Items;
