import React, { useContext } from "react";
import styles from "../styles/ItemCard.module.css";
import { itemContext } from "../intemcontext";
import { computeHeadingLevel } from "@testing-library/react";
function ItemCard({ prod}) {
  const value = useContext(itemContext)
  function handleAdd (prod){
    const index = value.cart.findIndex((item)=>item.id == prod.id);
    if(index===-1){
      value.setCart([...value.cart, {...prod, qty:1}])
    }else{
      value.cart[index].qty++
      value.setCart(value.cart)
    }
    value.setTotal(value.total+prod.price)
    value.setItem(value.item+1)

  };

  const handleRemove = (e, prod) => {
    e.preventDefault();
    if(value.item>0&&value.total>0){
      const index = value.cart.findIndex((item)=>item.id==prod.id)
      if(index===-1){
        return
      }else{
        value.cart[index].qty > 1?value.cart[index].qty--:value.cart.splice(index, 1)
        value.setCart(value.cart)
      }
      value.setTotal(value.total-prod.price)
      value.setItem(value.item-1)
    }
    
  };

  return (
    <div className={styles.itemCard}>
      <div className={styles.itemName}>{prod.name}</div>
      <div className={styles.itemPrice}>&#x20B9; {prod.price}</div>
      <div className={styles.itemButtonsWrapper}>
        <button className={styles.itemButton} onClick={() => handleAdd(prod)}>
          Add
        </button>
        <button className={styles.itemButton} onClick={(e) => handleRemove(e,prod)}>
          Remove
        </button>
      </div>
    </div>
  );
}

export default ItemCard;
