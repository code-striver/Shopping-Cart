import React, { useContext } from "react";
import styles from "../styles/Total.module.css";
import { itemContext } from "../intemcontext";
import styled from '../styles/Navbar.module.css'
function Navbar() {
  const value = useContext(itemContext);
  function handleReset(e){
    e.preventDefault();
    value.setTotal(0);
    value.setItem(0)
  }
  return (
    <div className={styles.container}>
      <h1>Total : &#x20B9; {value.total}</h1>
      <h1>Items: {value.item}</h1>
      <button className={styled.button} onClick={value.toggle}>cart</button>
      <button className={styled.button} onClick={handleReset}>Reset</button>
    </div>
  );
}

export default Navbar;
